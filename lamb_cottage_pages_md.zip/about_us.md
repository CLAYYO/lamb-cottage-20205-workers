# About Us

The **About Us** page describes Lamb Cottage Caravan Park’s setting in the heart of Cheshire’s Vale Royal region.  The park occupies **7½ acres** and is surrounded by farmland, providing a rural atmosphere away from main roads.  Its adults‑only policy and tranquil location make it ideal for a relaxing break【294656036189108†L65-L68】.

Within the touring park, visitors can book **41 super pitches**—fully serviced with 16‑amp electric, water and grey‑waste drain, each with hardstanding and a lawn—and **30 seasonal pitches**【294656036189108†L70-L75】.  Management emphasises its commitment to excellent pitches, peaceful surroundings and immaculate facilities【294656036189108†L77-L78】.

The page lists numerous awards: AA Campsite of the Year (regional), AA Gold Pennant awards for 2016–2020, a Visit England 2016 award, Visit Britain 5 star grading, AA 5 pennants and inclusion in the Top 100.  Lamb Cottage is also a member of **Tranquil Parks**【294656036189108†L80-L92】.

Because the park is owner‑managed, there is no shop on site and office hours may be limited during quiet periods; however, a **24‑hour contact number** is displayed for urgent assistance【294656036189108†L93-L97】.  Arrivals are welcome from **1 pm** (until **5 pm**, extended to **8 pm** on Fridays) and guests may arrive up to **8 pm** on any day【294656036189108†L99-L103】.
