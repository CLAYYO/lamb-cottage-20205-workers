# Access Statement

The **Access Statement** page provides information to help visitors determine if Lamb Cottage suits their needs.  Roads, paths and pitch hardstanding areas are gravel; other areas are grass, and the park is mostly level【394885796077307†L70-L71】.  Electric hook‑ups provide **16 amps**.  Mobile reception is very good on Vodafone but can be patchy on other networks; Wi‑Fi and TV reception are generally good, and lighting is low‑level between dusk and dawn【394885796077307†L73-L85】.

The reception office is approached via five paved steps with handrails and has a bell for attention; large‑print information sheets are available on request【394885796077307†L86-L97】.  Caravan pitches each have an electric point, water tap and grey‑waste drain on gravel hardstanding with a lawn; motorhome pitches are level gravel with shared water point【394885796077307†L100-L108】.

The amenity building is raised and reachable by steps or a **1‑in‑12 ramp**【394885796077307†L112-L114】.  The disabled suite is a wet room equipped with grab handles, non‑slip wash stool and an emergency alarm【394885796077307†L119-L121】.  Dishwashing and laundry facilities are at standard height; coin machines for appliances are above the worktops and assistance is available【394885796077307†L123-L127】.  An information shed provides maps and tourist leaflets【394885796077307†L129-L134】.
