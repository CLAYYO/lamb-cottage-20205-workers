# Christmas 2020 Update

This news post, published in late 2020, announces that Lamb Cottage Caravan Park reopened on **3 December 2020**.  It notes that the park’s opening period was extended until **31 January 2020** and that gift vouchers (£30, £50 and £100) were available for purchase【226623615025768†L65-L79】.  

The post mentions a brand‑new **2021 static holiday show home** arriving for Christmas with viewings carried out under strict COVID‑19 precautions【226623615025768†L75-L81】.  It also highlights several local festive attractions, such as Chester Zoo’s baby rhino calf and Arley Hall & Gardens’ wildlife art exhibition【226623615025768†L99-L134】.  Cheshire Oaks designer outlet re‑opened on 2 December with extended hours and safety measures【226623615025768†L142-L152】.
