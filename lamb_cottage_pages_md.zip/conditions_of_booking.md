# Conditions of Booking

Lamb Cottage’s **park rules and booking conditions** include:

- **Adults‑only** policy: the park is restricted to guests over 18 years【880151494610389†L69-L74】.
- **Deposits and payments:** a **£30 non‑refundable deposit** (£60 on bank holidays) is required for all bookings; single‑night stays must be paid in full【880151494610389†L75-L79】.  Minimum stay is **4 nights** for Easter and Christmas/New Year and **3 nights** for other bank holidays【880151494610389†L75-L80】.
- **Cancellation:** deposits are non‑refundable but may be transferred to a new booking within six months if at least **28 days’ notice** is given【880151494610389†L82-L86】.  During the COVID‑19 crisis, bookings can be moved free of charge if cancellations are due to restrictions or symptoms, and full refunds are offered if the park must close【880151494610389†L88-L100】.
- **Arrival and departure:** arrivals are permitted from **1 pm** and should not occur before this time; the latest arrival is **8 pm**【880151494610389†L104-L107】.  Pitches must be vacated by **12 noon** on departure day【880151494610389†L109-L110】.
- **Dogs:** only quiet, non‑aggressive dogs are accepted.  Dogs must be on a lead and cleaned up after.  They are not allowed on the veranda around the toilet block【880151494610389†L112-L119】.
- **Day visitors:** up to two visitors per pitch, all over 18, must park in the visitors’ car park and leave by 9:30 pm【880151494610389†L121-L124】.
- **Smoking:** no smoking on the veranda or in any park buildings; violators may be asked to leave without refund【880151494610389†L126-L129】.
- **General rules:** no commercial or lettered vehicles, no washing of cars or caravans except for seasonal pitches (and no hosepipes), no washing lines or rotary airers.  Only hook‑on window airers are allowed.  BBQs must not be placed on grass【880151494610389†L131-L142】.  
- Management reserves the right to refuse admission or terminate stays due to unacceptable conduct【880151494610389†L144-L146】.
