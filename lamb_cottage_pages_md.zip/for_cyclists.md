# For Cyclists

The **For Cyclists** page suggests local cycling options for guests staying at Lamb Cottage.  It highlights the **Whitegate Way** and **Delamere Cycling Trails**, each linked to more information【381238959629731†L65-L76】.  

The page also encourages visitors to use **Tracs Cycle Hire at Delamere**, providing a link to the bike‑hire service【381238959629731†L78-L82】.
