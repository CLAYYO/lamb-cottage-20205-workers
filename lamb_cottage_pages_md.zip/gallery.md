# Image Gallery

The **Lamb Cottage Gallery** page features a collection of photographs showcasing the park and its surroundings.  The page contains minimal text beyond the gallery heading【837105695062306†L65-L67】.
