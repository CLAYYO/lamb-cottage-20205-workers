# Get in Touch

The **Get in Touch** page provides contact information and a form for enquiries.  It lists the park’s address — **Lamb Cottage Caravan Park, Dalefords Lane, Whitegate, Nr. Northwich, Cheshire CW8 2BN** — along with the telephone number **01606 882 302** and email **info@lambcottage.co.uk**【583596420640631†L70-L88】.

Visitors are invited to fill in a form with their first and last names, email address, phone number, arrival date, leaving date and comments【583596420640631†L90-L121】.  

Service hours: arrivals should be scheduled between **1 pm and 6 pm**, with extended arrival to **8 pm on Fridays**.  The park closes during the winter from **2 January – 28 February**【583596420640631†L133-L147】.
