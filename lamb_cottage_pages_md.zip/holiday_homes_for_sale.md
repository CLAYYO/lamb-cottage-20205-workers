# Holiday Homes for Sale

This page targets visitors considering retirement from touring or seeking a more permanent leisure retreat.  Lamb Cottage offers a small, exclusive development of luxury static caravans for private ownership.  These holiday homes are licensed for use **10 months of the year (1 March – 2 January)**【65821285642702†L65-L80】.

As with the touring park, the development is adults‑only to ensure a tranquil environment【65821285642702†L81-L83】.  Pitches are spacious with private parking and meticulously maintained lawns.  Underground piped gas eliminates the need for visible gas bottles【65821285642702†L84-L86】.

Pitch fees include VAT, rates, water and grounds maintenance; gas and electricity are metered and invoiced annually.  Fees for 2020 were **£2,900**, payable over ten monthly instalments【65821285642702†L88-L91】.

The page advertises three new static holiday homes for sale with prices starting at **£48,000**【65821285642702†L95-L103】.  Features highlighted for one model include a galvanised chassis with a 10‑year warranty, robust wall construction, steel roof, LED lighting, uPVC windows, thick insulation and a host of interior comforts such as central heating, high ceilings, luxury furnishings and integrated kitchen appliances【65821285642702†L109-L173】.
