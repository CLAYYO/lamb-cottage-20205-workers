# Home Page

The home page of the Lamb Cottage Caravan Park website welcomes visitors and introduces the park as an award‑winning, adults‑only park set in **7½ acres** of meticulously maintained lawns and landscaped grounds.  It invites guests to relax and unwind and highlights that the park accommodates caravans, motorhomes and privately owned holiday homes【335218230018907†L75-L83】.  

Key features listed on the home page include the park’s award‑winning status, immaculate and landscaped grounds, excellent facilities, and easy access to Chester【335218230018907†L85-L92】.  The touring park is open from March until 2 January each year and offers seasonal pitches and luxury static caravans for private ownership【335218230018907†L96-L102】.  

Facilities are summarised in sections that mention free hot water and showers, fully fitted laundry, free hairdryers and shaver points, a dishwashing and veg‑prep area, a full disabled suite and a dog‑walking area【335218230018907†L115-L145】.  Additional facilities include electric hook‑ups, a motor‑home service point, chemical toilet disposal, an information centre with library, payphone and a small woodland dog walk【335218230018907†L146-L153】.  A site summary notes that the park offers **41 super pitches** and **30 seasonal pitches** with hardstanding and services【335218230018907†L189-L200】.

Contact details are provided at the bottom of the page: **Lamb Cottage Caravan Park, Dalefords Lane, Whitegate, Nr. Northwich, Cheshire CW8 2BN** along with telephone number **01606 882302** and email **info@lambcottage.co.uk**【335218230018907†L223-L231】.
