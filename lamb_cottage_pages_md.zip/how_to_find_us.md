# How to Find Us

The **How to Find Us** page explains that Lamb Cottage Caravan Park is located just over **one mile off the A556** dual carriageway at Sandiway【904662366214673†L65-L76】.

Directions are provided from several routes:

- **From M6 Junction 19:** take the A556 towards Northwich and turn left at traffic lights into Dalefords Lane, then proceed for just over a mile; the entrance is on the right between a white house and a white bungalow【904662366214673†L70-L76】.
- **From M56 Junction 10 and A49 northbound:** follow the A49 south and turn left onto the A556, then turn right at traffic lights into Dalefords Lane.  Continue just over a mile; the entrance is on the right【904662366214673†L79-L86】.
- **From A49 southbound:** turn right onto the A556 and then right again at traffic lights into Dalefords Lane; the entrance is just over a mile along on the right【904662366214673†L88-L95】.

GPS coordinates are provided: **West 2° 34.834’**, **North 53° 13.074’**【904662366214673†L97-L100】.
