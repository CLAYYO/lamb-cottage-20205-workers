# Local Attractions

The **Local Attractions** page lists numerous events and sites in Cheshire and surrounding areas.  Highlights include:

- **Chester Christmas Market (16 Nov – 22 Dec):** more than 70 traditional wooden chalets offering local products, crafts, gifts and festive food and drink【586295003680724†L72-L85】.
- **Arley Hall Shopping Fair:** established in 1991, featuring over 60 hand‑picked stalls and attracting around 1,500 visitors【586295003680724†L90-L95】.
- **Whitegate Daffodil Walk:** guided walks near Whitegate in support of Macmillan Cancer Support【586295003680724†L99-L104】.
- **RHS Flower Show at Tatton Park:** a large gardening event with free parking; premium parking costs £8【586295003680724†L108-L123】.
- **Storyhouse Chester:** a cultural charity housing a library, theatres and cinema; the library has the longest opening hours of any UK public library and runs over 2,000 sessions annually for marginalised communities【586295003680724†L126-L136】.
- **Royal Cheshire Show:** a long‑running agricultural show featuring competitions for livestock and rural activities【586295003680724†L141-L156】.
- **Beeston Castle:** an impressive ruin built in the 1220s that served as a royal stronghold and endured a siege during the Civil War【586295003680724†L161-L169】.
- **Chester Food & Drink Festival (28–30 Aug 2021):** a festival at Chester Racecourse with celebrity chefs John Torode and Gregg Wallace【586295003680724†L173-L190】.

The page includes links to many other attractions such as Jodrell Bank Discovery Centre, Tatton Park, Arley Hall & Gardens, Lion Salt Works Museum, canal walks, Blue Planet Aquarium, Albert Dock and more【586295003680724†L196-L210】.
