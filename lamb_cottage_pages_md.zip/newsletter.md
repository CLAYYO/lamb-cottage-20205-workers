# Newsletter Sign‑Up

The **Newsletter** page invites visitors to join Lamb Cottage’s mailing list.  It provides fields for a name and email address and asks for consent to be contacted via email for news, updates and marketing.  The page emphasises respect for personal data and explains that subscribers can withdraw consent at any time【245193751359300†L65-L80】.
