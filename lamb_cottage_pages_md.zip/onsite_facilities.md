# On‑Site Facilities

Lamb Cottage prides itself on offering **five‑star, luxury facilities**.  The modern, centrally heated amenity building includes luxury en‑suite style shower rooms (each with shower, toilet and washbasin) and separate toilets and handbasins【196311324679190†L65-L70】.

Highlighted amenities include free hot water and showers, a fully fitted laundry, free hairdryers and shaver points, a dishwashing and vegetable‑prep area, a full disabled suite and a dog‑walking area【196311324679190†L74-L94】.  Additional facilities are electric hook‑ups, a motor‑home service point with drive‑over waste‑disposal, a chemical toilet disposal point, an information centre with library, a payphone and a small on‑site woodland dog walk【196311324679190†L96-L103】.  Free Wi‑Fi is also available【196311324679190†L105-L106】.
