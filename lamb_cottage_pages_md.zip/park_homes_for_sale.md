# Park Homes for Sale

The **Park Homes for Sale** page reports that a brand‑new Tingdene Barnwell park home was offered for sale but is **now sold**【956542662609279†L65-L70】.  It advises prospective buyers to contact the park office for information on current second‑hand properties【956542662609279†L75-L76】.
