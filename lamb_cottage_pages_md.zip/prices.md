# 2022 Price Tariff

The **2022 Price Tariff** page lists nightly fees per pitch, including free showers, hot water, hairdryers and Wi‑Fi【507712086100336†L65-L70】.  For **super pitches** (double hardstanding with 16‑amp electric, drinking water tap and grey‑waste drain), prices are **£35.00** during the standard season, **£40.00** during peak season and **£40.00** on bank holidays【507712086100336†L72-L87】.

Dogs (up to two unless arranged) cost **£1** per night regardless of season【507712086100336†L89-L101】.  Extra adults cost **£8** per night across all seasons【507712086100336†L104-L118】.  Extra cars cost **£1** per night【507712086100336†L120-L132】, and awnings are free【507712086100336†L134-L139】.

Standard season dates: **1 March–14 April**, **19 April–28 April**, **3 May–31 May** and **5 September–22 December**【507712086100336†L143-L149】.  Peak season is **1 June–4 September**, and bank holidays (priced at the peak rate) cover **15–18 April**, **29 April–2 May**, **2–6 June**, **29 August–31 August** and **23 December–2 January**【507712086100336†L154-L165】.  Minimum stay is **4 nights** at Easter and **3 nights** at other bank holidays【507712086100336†L165-L167】.
